package com.example.madlabfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class UserDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "user_database";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "users";
    private static final String KEY_ID = "id";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_FIRST_NAME = "first_name";
    private static final String KEY_LAST_NAME = "last_name";
    private static final String KEY_AVATAR = "avatar";
    private static final String KEY_AVATAR_BYTES = "avatar_bytes";

    public UserDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                KEY_ID + " INTEGER PRIMARY KEY, " +
                KEY_EMAIL + " TEXT, " +
                KEY_FIRST_NAME + " TEXT, " +
                KEY_LAST_NAME + " TEXT, " +
                KEY_AVATAR + " TEXT, " +
                KEY_AVATAR_BYTES + " BLOB" +
                ")";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addUsers(List<User> users) {
        new AddUsersTask().execute(users);
    }

    private class AddUsersTask extends AsyncTask<List<User>, Void, Void> {
        @Override
        protected Void doInBackground(List<User>... params) {
            List<User> users = params[0];

            SQLiteDatabase db = getWritableDatabase();
            for (User user : users) {
                ContentValues values = new ContentValues();
                values.put(KEY_ID, user.getId());
                values.put(KEY_EMAIL, user.getEmail());
                values.put(KEY_FIRST_NAME, user.getFirstName());
                values.put(KEY_LAST_NAME, user.getLastName());
                values.put(KEY_AVATAR, user.getAvatar());

                Bitmap avatarBitmap = getBitmapFromUrl(user.getAvatar());
                if (avatarBitmap != null) {
                    byte[] avatarBytes = bitmapToByteArray(avatarBitmap);
                    values.put(KEY_AVATAR_BYTES, avatarBytes);
                }

                db.insert(TABLE_NAME, null, values);
            }
            db.close();

            return null;
        }

        private Bitmap getBitmapFromUrl(String imageUrl) {
            try {
                URL url = new URL(imageUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                return bitmap;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        private byte[] bitmapToByteArray(Bitmap bitmap) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            return stream.toByteArray();
        }
    }

    public void getUsers(GetUsersCallback callback) {
        new GetUsersTask(callback).execute();
    }

    private class GetUsersTask extends AsyncTask<Void, Void, ArrayList<User>> {
        private GetUsersCallback callback;

        public GetUsersTask(GetUsersCallback callback) {
            this.callback = callback;
        }

        @Override
        protected ArrayList<User> doInBackground(Void... params) {
            ArrayList<User> users = new ArrayList<>();

            SQLiteDatabase db = getWritableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
            if (cursor.moveToFirst()) {
                do {
                    User user = new User();
                    user.setId(cursor.getInt(0));
                    user.setEmail(cursor.getString(1));
                    user.setFirstName(cursor.getString(2));
                    user.setLastName(cursor.getString(3));
                    user.setAvatar(cursor.getString(4));

                    byte[] avatarBytes = cursor.getBlob(5);
                    if (avatarBytes != null) {
                        Bitmap avatarBitmap = BitmapFactory.decodeByteArray(avatarBytes, 0, avatarBytes.length);
                        user.setAvatarBitmap(avatarBitmap);
                    }

                    users.add(user);
                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();

            return users;
        }

        @Override
        protected void onPostExecute(ArrayList<User> users) {
            callback.onUsersLoaded(users);
        }
    }

    public interface GetUsersCallback {
        void onUsersLoaded(ArrayList<User> users);
    }
}





