package com.example.madlabfinal;

import java.util.ArrayList;

public class UserResponse {
    private ArrayList<User> data;

    public ArrayList<User> getData() {
        return data;
    }

    public void setData(ArrayList<User> data) {
        this.data = data;
    }
}